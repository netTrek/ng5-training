import { Component } from '@angular/core';
import { ActivatedRoute, Router, UrlSegment } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Component ( {
  selector   : 'nt-root',
  templateUrl: './app.component.html',
  styleUrls  : [ './app.component.scss' ]
} )
export class AppComponent {

  title = 'nt';

  constructor ( public router: Router ) {}

  isPopUpRouteActive ( path: string ): boolean {
    return this.router.url.indexOf( path ) !== -1;
  }
}
