import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'nt-pop1',
  templateUrl: './pop1.component.html',
  styleUrls: ['./pop1.component.scss']
})
export class Pop1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
