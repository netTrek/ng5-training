import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'nt-pop2',
  templateUrl: './pop2.component.html',
  styleUrls: ['./pop2.component.scss']
})
export class Pop2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
