import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Pop1Component } from './pop1/pop1.component';
import { Pop2Component } from './pop2/pop2.component';
import { RouterModule } from '@angular/router';
import { ClosePopUpDirective } from './close-pop-up.directive';

@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  declarations: [Pop1Component, Pop2Component, ClosePopUpDirective],
  exports: [Pop1Component, Pop2Component]
})
export class PopupModule { }
